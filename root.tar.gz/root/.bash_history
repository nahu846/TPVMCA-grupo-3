history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
vi /etc/hosts
vi /etc/hosts
hostnamectl
systemctl restart systemd-login
reboot now
hostnamectl --help
hostnamectl set-hostmane TPServer
set-hostmane --static TPServer
set-hostname --static TPServer
hostnamectl --static set-hostname TPServer
reboot now
cat /etc/os-release 
apt update
ip a
ping 8.8.8.8
vim /etc/apt/sources.list
cd /etc/apt/
ls -la
cp -a sources.list sources.list-old
vim sources.list
apt install openssh
vim sources.list
vim sources.list
apt update
vim sources.list
apt update
apt full-upgrade
reboot now
lsb_release -a
apt-get install openssh
apt-get install openssh-server
vim /etc/ssh/sshd_config
ip a
vim /etc/ssh/sshd_config
service status openssh
service --status-all
service status ssh
reboot now
systemctl status ssh
ls
ip a
ssh-keygen
ls
cat palermo.pub >> ./.ssh/authorized_keys
vin ./.ssh/authorized_keys 
vim ./.ssh/authorized_keys 
apt install apache2
systemctl enable apache2
systemctl start apache2
systemctl status apache2
ls -la
gunzip Material_Adicional_TPVMCA.tar.gz 
ls -la
man tar
tar --extract -f Material_Adicional_TPVMCA.tar 
ls -la
ls -la Material_Adicional_TPVMCA
rm palermo*
cat clave_publica.pub >> /root/.ssh/authorized_keys
cat Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
vim /etc/apache2/apache2.conf 
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
systemctl status apache2
vim /etc/apache2/mods-enabled/dir.conf 
systemctl restart apache2
systemctl status apache2
ls -la
chmod 777 -R Material_Adicional_TPVMCA
apt install php
systemctl restart apache2
systemctl status apache2
ls -la Material_Adicional_TPVMCA
php -v
apache enmod 
apache2 enmod 
apache2 enmod -L
apache2 -L
enmod
apache2enmod
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkdir /www_dir
ls
mkdir /backup_dir
mount /dev/sdb1 /www_dir
df -h
reboot
df -h
lsblk
mount -vvv /dev/sdc1 /www_dir
ip a
vim /etc/apt/sources.list
vim /etc/apt/sources.list
vim /etc/apt/sources.list-old 
vim /etc/apt/sources.list
clear
reboot
df -h
apt install apache2 php libapache2-mod-php
ip a
ping 8.8.8.8
vim /etc/network/interfaces
systemctl restart networking
ping 8.8.8.8
ip a
ip a
systemctl restart networking
ip a
ping 8.8.8.8
apt install apache2 php libapache2-mod-php
lsblk
history
man mkfs
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
ls /
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /www_dir
ls
ls Material_Adicional_TPVMCA
mount /dev/sdc2 /backup_dir/
ls -la
lsblk
umount /dev/sdc2 /www_dir
ls -la
lsblk
mount /dev/sdc2 /backup_dir/
lsblk
cp Material_Adicional_TPVMCA/index.php Material_Adicional_TPVMCA/logo.png /www_dir/
vim /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
ip a
vim /etc/fstab 
history -w
df -h
apt install apache2 php libapache2-mod-php
ip a
ping 8.8.8.8
vim /etc/network/interfaces
systemctl restart networking
ping 8.8.8.8
ip a
ip a
systemctl restart networking
ip a
ping 8.8.8.8
apt install apache2 php libapache2-mod-php
lsblk
history
man mkfs
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
ls /
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /www_dir
ls
ls Material_Adicional_TPVMCA
mount /dev/sdc2 /backup_dir/
ls -la
lsblk
umount /dev/sdc2 /www_dir
ls -la
lsblk
mount /dev/sdc2 /backup_dir/
lsblk
cp Material_Adicional_TPVMCA/index.php Material_Adicional_TPVMCA/logo.png /www_dir/
vim /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
ip a
vim /etc/fstab 
history -w
reboot
chown www-data:www-data /www_dir/*
ip a
df -h
df -h
vim /etc/fstab 
df -h
umount /home
df -h
reboot
df -h
ls -la /www_dir/
ls -la /www_dir
chmod 755 /www_dir
chmod 644 /www_dir/*
chown -R www-data:www-data /www_dir
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf 
vim /etc/apache2/apache2.conf 
apache2ctl configtest
systemctl restart apache2
vim /www_dir/index.php 
df -h
cat /proc/partitions > /opt/particion
vim /opt/particion 
reboot
vim /proc/partitions 
lsblk
shutdown now
df -h
php -v
apache2ctl -M | grep php
a2enmod php8.2
mkdir -p /opt/scripts
cat > /opt/scripts/backup_full.sh << 'EOF'
#!/bin/bash

show_help() {
  echo "Uso: $0 -s <origen> -d <destino>"
  echo "  -s  directorio de origen a respaldar"
  echo "  -d  directorio destino donde guardar el backup"
  echo "  -help  muestra esta ayuda"
  exit 0
}

ORIGEN=""
DESTINO=""

[[ "$1" == "-help" ]] && show_help

while getopts "s:d:" opt; do
  case $opt in
    s) ORIGEN="$OPTARG" ;;
    d) DESTINO="$OPTARG" ;;
    *) show_help ;;
  esac
done

if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
  echo "Error: se requieren -s y -d"; show_help
fi

# Validar que origen y destino existen y están montados
if ! mountpoint -q "$DESTINO" && [[ ! -d "$DESTINO" ]]; then
  echo "Error: el destino $DESTINO no está disponible"; exit 1
fi
if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: el origen $ORIGEN no existe"; exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO" "$ORIGEN" && echo "Backup guardado en $ARCHIVO" || echo "Error al crear backup"
EOF

chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh -help
vim /opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh -help
vim /opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh -help
vim /opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
vim /opt/scripts/backup_full.sh 
cat /opt/scripts/backup_full.sh 
vim /opt/scripts/backup_full.sh 
vim /opt/scripts/backup_full.sh 
crontab -e
crontab -e
apt install nano
crontab -e
cat Material_Adicional_TPVMCA/index.php 
apt install mysql-server
apt install mariadb-server
mysql -u root < Material_Adicional_TPVMCA/db.sql 
mysql -u lcars -pNCC1701D ingenieria -e "SHOW TABLES;"
php -r "new mysqli('localhost','lcars','NCC1701D','ingenieria'); echo 'OK';"
apt install php-mysql
apt-get update
apt install php-mysql
php -r "new mysqli('localhost','lcars','NCC1701D','ingenieria'); echo 'OK';"
systemctl restart apache2
vim /etc/apt/sources.list
ls
ls -la
gunzip 
history
vim /etc/ssh/sshd_config
history
history | grep apt
vim /etc/apache2/apache2.conf 
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf 
systemctl restart apache2
ls -la
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf 
systemctl restart apache2
vim /etc/apache2/apache2.conf 
vim /etc/apache2/sites-available/000-default.conf 
chmod 700 /root/
chmod 755 /root/
vim /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
chmod 700 /root/
vim /opt/scripts/backup_full.sh 
cat /opt/scripts/backup_full.sh 
ls -la /opt/scripts/backup_full.sh 
ls
vim /etc/fstab 
shutdown
shutdown now
ls -la
ls -la Material_Adicional_TPVMCA
ls -l /
chmod 766 /root/
chmod 755 /root/
vim /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
